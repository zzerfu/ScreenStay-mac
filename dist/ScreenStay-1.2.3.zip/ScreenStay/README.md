# ScreenStay

一个 macOS 菜单栏小工具：**播放音乐或视频时自动阻止屏幕休眠，暂停或关闭后自动释放**。

- 菜单栏图标，**单击直接开关**，右键打开设置菜单
- 默认只监听 macOS 右上角播放列表中的媒体，连续提示音不会触发
- 右键菜单可查看当前正在影响熄屏的其他应用
- 开关关闭后完全不干预屏幕休眠
- 支持开机自启（使用 macOS 的 `SMAppService`）
- 无需辅助功能、屏幕录制、麦克风等权限
- 不联网、不上传任何数据
- 通用二进制，支持 Apple Silicon 与 Intel，最低 macOS 13

更新记录：[CHANGELOG.md](CHANGELOG.md)

## 安装

### 方式一：双击安装脚本（推荐）

1. 双击 `install.command`
2. 脚本会把 App 复制到 `/Applications` 并打开
3. 右上角菜单栏出现显示器图标

### 方式二：从 DMG 安装

双击 `dist/ScreenStay-1.2.3.dmg`，把 **ScreenStay** 拖到 **Applications** 文件夹，然后打开。

### 方式三：手动拖入

把 `ScreenStay.app` 拖到 **应用程序** 文件夹，然后双击打开。

> 首次打开如果被 Gatekeeper 拦截，请在「系统设置 → 隐私与安全性」中点“仍要打开”，或在终端执行：
> `xattr -dr com.apple.quarantine /Applications/ScreenStay.app`

## 使用

- **单击**菜单栏的显示器图标：立即开启/关闭保护。
- **右键**（或 Control+单击）图标：打开设置菜单。

菜单内容：

```
正在播放 · QQMusic
屏幕保持常亮
其他影响熄屏的应用（1）
  WorkBuddy
────────────
✓ 保持屏幕常亮
✓ 仅系统媒体播放时触发
  开机自动启动
  关于 ScreenStay
  退出 ScreenStay
```

- **保持屏幕常亮**：总开关（与单击图标等价）。取消勾选后立即释放电源断言，不再阻止熄屏。
- **仅系统媒体播放时触发**：默认开启的严格模式。只认可 macOS 右上角播放列表（Now Playing）里的媒体播放，普通提示音、点击音效、后台音频不会触发。
  - 关闭此开关后，会回退到 `Core Audio + Now Playing` 兼容模式，任何持续 2.5 秒以上的音频输出都可能触发。
- **开机自动启动**：注册为登录项。若 macOS 要求批准，会引导到「系统设置 → 通用 → 登录项」。
- 图标右侧出现 **绿点**：正在播放媒体，且已成功保持屏幕常亮。
- 图标变暗：功能已关闭。
- 关闭开关（单击图标或在菜单中取消勾选）、退出 App 或暂停媒体后，电源断言会释放。

### 查看谁在阻止熄屏

右键菜单会实时显示当前持有“阻止显示器休眠”断言的其他应用，例如：

```
其他影响熄屏的应用（1）
  WorkBuddy
```

如果列表为空，说明没有其他应用在阻止熄屏。若你发现屏幕不按设定时间熄灭，可以先看这里：macOS 会汇总所有应用的电源断言，ScreenStay 无法取消其他应用的防熄屏请求，需要退出对应应用或关闭它的“保持常亮”选项。

> ScreenStay 只阻止“空闲熄屏/系统休眠”。手动锁屏、合盖、低电量等情况仍按 macOS 自身策略执行。

## 检测原理

默认使用 **严格模式**：只监听系统 Now Playing 状态，也就是点击 macOS 右上角控制中心后能看到的那条“正在播放”媒体信息。

- 普通提示音、系统音效、后台音频不会出现在 Now Playing，因此不会触发
- 播放开始后立即保持亮屏
- 媒体停止后延迟约 5 秒释放，避免暂停/切换曲目时闪烁

严格模式关闭后，才会额外采样 **Core Audio 输出设备活动**，用于兼容没有登记 Now Playing 的播放器。此时任何持续约 2.5 秒以上的音频输出都可能触发，包括连续提示音。

两种模式都只读取系统播放状态，不需要辅助功能或屏幕录制权限，也不修改任何播放器状态。

严格模式使用两层只读查询：

1. **内置 Perl 辅助器**：通过 `/usr/bin/perl` 加载 App 内置的一个极小 dylib，调用 `MRMediaRemoteGetNowPlayingApplicationIsPlaying`。macOS 15.4 对普通 App 拦截了该接口，但系统 Perl 被允许访问，因此能得到真实的播放/暂停状态。
2. **JXA 辅助脚本**：只在确认播放时读取应用名、标题、PID 和 Bundle ID，用于菜单展示。

如果 Perl 辅助器不可用，会回退到 `PlaybackRate + 播放器进程音频输出 + isCurrentlyPlaying` 的组合判断。

暂停后通常 1–2 秒内释放，避免“已暂停但图标还是绿的”。

> macOS 15.4 之后，普通第三方 App 直接调用 MediaRemote 的 C 接口或 `MRNowPlayingRequest` 类属性会返回过期的 Paused。ScreenStay 1.2.3 使用系统 Perl 作为受信任的读取进程，不需要辅助功能、屏幕录制或麦克风权限。

打开保护时，App 会创建两个 IOPM 电源断言：

- `PreventUserIdleDisplaySleep`
- `PreventUserIdleSystemSleep`

可以用下面的命令确认：

```bash
pmset -g assertions | grep ScreenStay
```

### 已知限制

- 严格模式下，如果某个播放器没有向系统登记 Now Playing（不出现在右上角播放列表），就不会触发；可以临时关闭“仅系统媒体播放时触发”回退到音频检测。
- 如果播放器暂停后仍长期保持音频输出流、同时不更新 `PlaybackRate`，释放可能稍有延迟；这类播放器很少。
- 如果某个播放器播放**完全静音的视频**，又没有向系统登记 Now Playing，同样可能识别不到。
- App 不模拟鼠标/键盘，不修改系统节能设置，也不申请辅助功能权限。
- 移动 App 位置后，已注册的开机自启可能指向旧路径；关闭再打开一次“开机自动启动”即可。

## 诊断

App 内置命令行诊断，不需要打开菜单：

```bash
# 观察 10 秒检测状态与电源断言
/Applications/ScreenStay.app/Contents/MacOS/ScreenStay --diagnose 10

# 查看当前影响熄屏的其他应用
/Applications/ScreenStay.app/Contents/MacOS/ScreenStay --blockers

# 直接查看系统 Now Playing 状态
/Applications/ScreenStay.app/Contents/MacOS/ScreenStay --nowplaying

# 查看 / 开启 / 关闭登录项
/Applications/ScreenStay.app/Contents/MacOS/ScreenStay --login-status
/Applications/ScreenStay.app/Contents/MacOS/ScreenStay --enable-login
/Applications/ScreenStay.app/Contents/MacOS/ScreenStay --disable-login
```

诊断输出示例：

```
ScreenStay diagnostics
  nowPlaying API: available
  trigger: Now Playing only (strict)
  duration: 8s
[+0.1s] audio=no nowPlaying=no playing=no assertion=none source=-
[+2.0s] audio=no nowPlaying=yes playing=yes assertion=held source=QQMusic
[+8.0s] audio=no nowPlaying=no playing=no assertion=none source=-
```

播放音乐时运行 `--nowplaying`，应该看到：

```text
source=jxa
isPlaying=true
playbackRate=1
app=QQ音乐
title=歌曲名
```

`perlIsPlaying` 是最终判定；`source=jxa` 部分用于读取应用名和元数据。下面的 `requestAPI=...` 是兼容/诊断信息，旧接口在 macOS 15.4+ 可能仍显示 Paused。

## 制作 / 分发 DMG

自己使用不需要额外准备。当前 `dist/ScreenStay-1.2.3.dmg` 已经包含 App、Applications 快捷方式和说明文件，使用 ad-hoc 签名即可。

如果要发给别人，需要准备：

1. **Apple Developer Program 账号**（个人或公司）
2. **Developer ID Application 证书**（安装在钥匙串）
3. 使用 hardened runtime 签名 App，再用 `notarytool` 公证
4. 对 DMG 本身签名并公证，最后 `stapler` 装订票据

否则 Gatekeeper 会提示“无法验证开发者”，对方需要右键打开或手动移除 quarantine。

示例（把证书名、Team ID、钥匙串配置换成自己的）：

```bash
# 1. 签名 App（分发版建议启用 hardened runtime）
codesign --force --deep --options runtime --timestamp \
  --sign "Developer ID Application: Your Name (TEAMID)" ScreenStay.app

# 2. 保存一次公证凭据
xcrun notarytool store-credentials "AC_PASSWORD" \
  --apple-id "you@example.com" --team-id "TEAMID" --password "app-specific-password"

# 3. 先公证 App，再装订
ditto -c -k --keepParent ScreenStay.app /tmp/ScreenStay.zip
xcrun notarytool submit /tmp/ScreenStay.zip --keychain-profile "AC_PASSWORD" --wait
xcrun stapler staple ScreenStay.app

# 4. 重新制作 DMG，签名并公证 DMG
codesign --force --sign "Developer ID Application: Your Name (TEAMID)" \
  ScreenStay-1.2.3.dmg
xcrun notarytool submit ScreenStay-1.2.3.dmg --keychain-profile "AC_PASSWORD" --wait
xcrun stapler staple ScreenStay-1.2.3.dmg
```

注意：本 App 读取了 MediaRemote 的 Now Playing 信息，属于私有框架调用，不适合提交 Mac App Store；通过 Developer ID 在 App Store 之外分发没有问题。

## 从源码构建

要求：macOS 13+、Command Line Tools（`swiftc`、`codesign`、`iconutil`）。

```bash
cd ScreenStay
./build.sh
open ScreenStay.app
```

构建脚本会：

- 分别编译 `arm64` 与 `x86_64`，再用 `lipo` 合并
- 生成 `ScreenStay.app`
- 在 `/tmp` 中完成 ad-hoc 签名（当前工作区由文件提供商托管，直接签名会带上 FinderInfo 扩展属性）
- 校验签名与 Info.plist

重新生成图标（可选，需要 Pillow）：

```bash
python3 scripts/make_icon.py
```

## 项目结构

```
ScreenStay/
├── ScreenStay.app              # 已构建的 App
├── CHANGELOG.md                # 1.0.0 至今的更新记录
├── build.sh                    # 构建脚本
├── install.command             # 安装到 /Applications
├── Sources/
│   ├── main.swift              # 入口与命令行参数
│   ├── AppDelegate.swift       # 菜单栏 UI
│   ├── MediaMonitor.swift      # 检测状态合并与防抖
│   ├── AudioActivityDetector.swift
│   ├── NowPlayingDetector.swift
│   ├── PowerController.swift   # IOPM 电源断言
│   ├── LoginItemManager.swift  # 开机自启
│   └── Diagnostics.swift
├── Resources/
│   ├── Info.plist
│   ├── AppIcon.icns
│   └── AppIcon-1024.png
└── scripts/make_icon.py
```

## 卸载

1. 点击菜单栏图标 → 取消“开机自动启动”
2. 点击“退出 ScreenStay”
3. 删除 `/Applications/ScreenStay.app`

如需清理偏好设置：

```bash
defaults delete com.zzerfu.ScreenStay
```
